%nn1R, Recognition of BP network
%===============
%ѵ���õ�BP����ʶ����������Ĳ�������
%===============
function exampleRe
%clc;
%[length,width]=size(b1);
%b=double(b1);
%q=reshape(b,length*width,1);  %��32*32�ľ���Ϊ1024*1�ľ���

%Recog=purelin(W2*tansig(W1*q,B1),B2); %����Բ���������ʵ�����
%Re=round(Recog); % ʶ���б�
%set(Hbp3_recog,'String',Re,'fontsize',65)

% ʶ��

for times=1
    clear all;
    p(1:256,1)=1;
    p1=ones(16,16);
    load E52net net;
    load pic pathname
    %test=input('����',int2str(kk),'.bmp');
    %[name,path]=uigetfile('*.bmp');
    %pathname=strcat(path,name);
    x=imread(pathname);
    bw=im2bw(x,0.5);
    [i,j]=find(bw==0);
    imin=min(i);
    imax=max(i);
    jmin=min(j);
    jmax=max(j);
    bw1=bw(imin:imax,jmin:jmax);
    rate=16/max(size(bw1));
    bw1=imresize(bw1,rate);
    [i,j]=size(bw1);
    i1=round((16-i)/2);
    j1=round((16-j)/2);
    p1(i1+1:i1+i,j1+1:j1+j)=bw1;
    p1=-1.*p1+ones(16,16);
    for m=0:15
        p(m*16+1:(m+1)*16,1)=p1(1:16,m+1);
    end
    [a,Pf,Af]=sim(net,p);
    imshow(p1);
    a=round(a);
    save answer a;
end

%
%[R,Q]=size(S);[S2,Q]=size(T);

%S1=str2num(S1);  %������Ԫ����

%W1=rands(R,S1);
%[W1,B1]=rands(S1,R);
%[W2,B2]=rands(S2,S1);
%A2=purelin(W2*tansig(W1*S,B1),B2);

%initialize the parameters
%disp_freq=20;
%max_epoch=str2num(max_epoch);
%err_goal=str2num(err_goal);
%lr=str2num(lr);  %ѧϰ����
%TP=[disp_freq max_epoch err_goal lr];
%training begins
%[W1,B1,W2,B2,epochs,errors]=trainbp(W1,B1,'tansig',W2,B2,'purelin',S,T,TP);

%ploterr(errors);
%out=purelin(W2*tansig(W1*S,B1),B2);  %ʵ�����

%SSE=sumsqr(T-out);

%fprintf('Trained network operates:');
%if SSE < err_goal
 %  disp('Adequately.')
 %else
 %  disp('Inadequately.')
 %end

   